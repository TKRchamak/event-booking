export default {
  cfs: {
    logoSize: 60,

    header1: 40,
    header2: 35,
    header3: 30,

    normal: 14,
    small: 10,
  },

  cfw: {
    smallest: "400",
    small: "500",
    mid: "600",
    big: "800",
    bigger: "900",
  },
};
